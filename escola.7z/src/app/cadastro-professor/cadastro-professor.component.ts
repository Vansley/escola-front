import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-cadastro-professores',
  templateUrl: './cadastro-professor.component.html',
  styleUrls: ['./cadastro-professor.component.css']
})
export class CadastroProfessorComponent implements OnInit {

  //atributos
  mensagem: string = '';


  constructor(
    private httpClient: HttpClient

  ) { }

  //montando a estrutura do formulário
  formCadastro = new FormGroup({
    //campos do formulário
    nome: new FormControl('', [Validators.required]),
    endereco: new FormControl('', [Validators.required]),
  });

  //acessando o formulário/campos na página HTML
  get form(): any {
    return this.formCadastro.controls;
  }

  ngOnInit(): void {
    // TODO document why this method 'ngOnInit' is empty


  }

  //função para fazer a chamada do cadastro na API
  onSubmit(): void {

    this.httpClient.post(
      environment.apiUrl + '/professores', this.formCadastro.value, { responseType: 'text' })
      .subscribe(
        data => {
          this.mensagem = data;
          this.formCadastro.reset();
        },
        e => {
          this.mensagem = "Ocorreu um erro, o cadastro não foi realizado.";
          console.log(e);
        }
      )
  }

}
