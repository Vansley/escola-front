import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-consulta-aluno',
  templateUrl: './consulta-aluno.component.html',
  styleUrls: ['./consulta-aluno.component.css']
})
export class ConsultaAlunoComponent implements OnInit {

  alunos: any[] = [];

  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient.get(environment.apiUrl+'/alunos').subscribe(

      (data)=> {

        this.alunos = data as any[];

      },
      (e) => {

        console.log(e);

      }
    )
  }

  // função para fazert a exclusão do produto na API
  excluir(idAluno:number):void{
    if(window.confirm('Deseja realmente excluir o aluno selecionado?')) {
      this.httpClient.delete(environment.apiUrl+ "/alunos/"+ idAluno,
      { responseType : 'text'})
      .subscribe(
        (data) =>{
          alert(data); // exibir mensagem em uma janela popup
          this.ngOnInit(); // recarregar a cunsulta de produtos
        },
        (e)=>{
          console.log(e);
        }
      )
    }
  }
}
