import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-consulta-alunosturma',
  templateUrl: './consulta-alunosturma.component.html',
  styleUrls: ['./consulta-alunosturma.component.css']
})
export class ConsultaAlunosturmaComponent implements OnInit {
  alunos: any[]=[];
  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient.get(environment.apiUrl+'/turmas').subscribe
    ((data)=>{
      this.alunos= data as any[];

    },
    (e)=> {
      console.log(e);
    }
    )
  }
    }
  


