import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-consulta-cursos',
  templateUrl: './consulta-curso.component.html',
  styleUrls: ['./consulta-curso.component.css']
})
export class ConsultaCursoComponent implements OnInit {

  cursos: any[] = [];

  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient.get(environment.apiUrl+'/cursos').subscribe(

      (data)=> {

        this.cursos = data as any[];

      },
      (e) => {

        console.log(e);

      }
    )
  }

  // função para fazert a exclusão do produto na API
  excluir(idCursos:number):void{
    if(window.confirm('Deseja realmente excluir o curso selecionado?')) {
      this.httpClient.delete(environment.apiUrl+ "/cursos/"+ idCursos,
      { responseType : 'text'})
      .subscribe(
        (data) =>{
          alert(data); // exibir mensagem em uma janela popup
          this.ngOnInit(); // recarregar a cunsulta de produtos
        },
        (e)=>{
          console.log(e);
        }
      )
    }
  }
}
