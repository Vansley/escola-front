import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-consulta-professores',
  templateUrl: './consulta-professor.component.html',
  styleUrls: ['./consulta-professor.component.css']
})
export class ConsultaProfessorComponent implements OnInit {

  professores: any[] = [];

  constructor(private httpClient: HttpClient) { }

  ngOnInit(): void {
    this.httpClient.get(environment.apiUrl+'/professores').subscribe(

      (data)=> {

        this.professores = data as any[];

      },
      (e) => {

        console.log(e);

      }
    )
  }

  // função para fazert a exclusão do produto na API
  excluir(idProfessor:number):void{
    console.log(idProfessor)
    if(window.confirm('Deseja realmente excluir o professor selecionado?')) {
      this.httpClient.delete(environment.apiUrl+ "/professores/"+ idProfessor,
      { responseType : 'text'})
      .subscribe(
        (data) =>{
          alert(data); // exibir mensagem em uma janela popup
          this.ngOnInit(); // recarregar a cunsulta de produtos
        },
        (e)=>{
          console.log(e);
        }
      )
    }
  }
}
