import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaTurmaComponent } from './consulta-turma.component';

describe('ConsultaTurmaComponent', () => {
  let component: ConsultaTurmaComponent;
  let fixture: ComponentFixture<ConsultaTurmaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsultaTurmaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsultaTurmaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
