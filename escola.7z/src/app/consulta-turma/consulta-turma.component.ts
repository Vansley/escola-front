import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-turma',
  templateUrl: './consulta-turma.component.html',
  styleUrls: ['./consulta-turma.component.css']
})
export class ConsultaTurmaComponent implements OnInit {


  ngOnInit(): void {
  }

}
