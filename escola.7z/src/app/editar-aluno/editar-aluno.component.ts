import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-editar-alunos',
  templateUrl: './editar-aluno.component.html',
  styleUrls: ['./editar-aluno.component.css']
})

export class EditarAlunoComponent implements OnInit {

  mensagem: string = '';

  constructor(private httpClient: HttpClient, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    //Capturar o id enviado pela URL
    const idAluno = this.activatedRoute.snapshot.paramMap.get('id') as string;

    // consultar o aluno na API através do id
    this.httpClient.get(environment.apiUrl+ "/alunos/"+ idAluno)
    .subscribe(
      (data:any) =>{
        //´reeenchendo os campos do formulário com os dados do aluno
        this.formEdicao.patchValue(data);
      },
      (e) => {
        console.log(e);
      }
    )
  }

  //montadno a estrurura do formulario
  formEdicao = new FormGroup({
    // campos do formulario
    idAluno: new FormControl(''),
    nome: new FormControl('',[Validators.required]),
    endereco: new FormControl('',[Validators.required])
  })

  // Acessando o fomrlário / campos na página HTML
  get form():any{
    return this.formEdicao.controls;
  }

//funcçãp para fazer a camada do edição na API
onSubmit ():void{
  this.httpClient.put(environment.apiUrl+ '/alunos', this.formEdicao.value,
  {responseType: 'text'})
  .subscribe(
    data => {
      this.mensagem = data;
    },
    e => {
      this.mensagem = "Ocorreu um erro, a edição não foi realizada.";
      console.log(e);
    }
  )
}

}
