import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-curso',
  templateUrl: './editar-curso.component.html',
  styleUrls: ['./editar-curso.component.css']
})
export class EditarCursoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
