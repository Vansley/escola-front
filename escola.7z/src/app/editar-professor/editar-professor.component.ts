import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-professor',
  templateUrl: './editar-professor.component.html',
  styleUrls: ['./editar-professor.component.css']
})
export class EditarProfessorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
