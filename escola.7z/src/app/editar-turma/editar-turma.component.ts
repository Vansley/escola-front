import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-editar-turmas',
  templateUrl: './editar-turma.component.html',
  styleUrls: ['./editar-turma.component.css']
})
export class EditarTurmaComponent implements OnInit {

  mensagem: string = '';

  constructor(private httpClient: HttpClient, private activateRoute: ActivatedRoute) { }

  ngOnInit(): void {

    const idTurma= this.activateRoute.snapshot.paramMap.get('id') as string;

    this.httpClient.get(environment.apiUrl + "/turmas/" + idTurma)
    .subscribe(
      (data: any) => {
        this.formEdicao.patchValue(data);
      },
      (e) => {
        console.log(e);
      }
    )
  }

  formEdicao = new FormGroup({

    idTurma: new FormControl(''),
    semestre: new FormControl('', [Validators.required]),
    ano: new FormControl('', [Validators.required]),
    
  })

  get form(): any {
    return this.formEdicao.controls;
  }

  onSubmit(): void {
    this.httpClient.put(environment.apiUrl + '/turmas/', this.formEdicao.value,
    {responseType: 'text'})
    .subscribe(
      e => {
        this.mensagem = e;
      },
      e => {
        this.mensagem = "Ocorreu um erro, a edição não foi realizada.";
        console.log(e);
      }
    )
  }

}